 <footer class="main-footer">
     <strong>Copyright &copy; 2021 <a target="_blank" href="">Mainul Photography</a>.</strong>
     All rights reserved.
     <div class="float-right d-none d-sm-inline-block">
         <a target="_blank" href="https://facebook.com/a.chobi7">Developed By <strong style="color: red">Saiful
                 Islam</strong> </a><b>|| Version</b> 2.1 pro
     </div>
 </footer>
