<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="{{ url('./saifulfav.png') }}">

    <meta name="keywords"
        content="printsale prints artsale art printsforsale photography sale print artist contemporaryart wallart fineartphotography illustration photographer photo artphotography photobook exhibition artwork printsavailable printshop printsforyourhome printmaking contemporaryartist photographicprints fineartprints printsales photographicbodyofwork calender best photo">
    <meta name="description"
        content="i am providing photographer for Wedding Photographers & project Photographers, corporate photographer, printed photo, digital photo. Call for photo @ 8801916665832/ 8801675909939| email: saiful.rana@gmail.com" />

    <meta itemprop="name" content="Freelance photographer">


    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="index, follow">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="language" content="English">
    <meta name="author" content="Mainul Photography.">
    <meta name="theme-color" content="#1b5e76">
    <meta name="robots" content="all">
    <meta name="Copyright" CONTENT="Mainul Photography.">
    <meta name="Publisher" CONTENT="Mainul Photography.">
    <meta name="distribution" CONTENT="Global">
    <meta name="Robots" CONTENT="INDEX,FOLLOW">
    <meta name="zipcode" CONTENT="1230">
    <meta name="city" CONTENT="Dhaka">
    <meta name="country" CONTENT="BD">
    <meta name="revisit-after" content="1">
    <meta name="geo.region" content="BD-13" />
    <meta name="geo.placename" content="Dhaka" />




    <title>Mainul Photo - @yield('fmenuname')</title>
    <link rel="stylesheet" type="text/css" href="{{ asset('frontend_assets/style/css/bootstrap.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('frontend_assets/style/css/plugins.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('frontend_assets/style/revolution/css/settings.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('frontend_assets/style/revolution/css/layers.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('frontend_assets/style/revolution/css/navigation.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('frontend_assets/style/type/icons.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('frontend_assets/style/style.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('frontend_assets/style/css/color/purple.css') }}">
</head>

<body>
